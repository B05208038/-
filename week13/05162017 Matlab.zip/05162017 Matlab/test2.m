F2=xlsread('cwb_466920_2006.csv');
Hr=F2(1:24,3);
Ta=F2(1:24,5);
Td=F2(1:24,6);

plot(Hr,Ta)
figure(101)
plot(Hr,Ta)

figure(110)
plot(Hr,Ta,'ob:',Hr,Td,'k-d')
legend('Ta','Td')
xlabel('Local time(Hr)')
ylabel('Temperature(^{o}C)')
title('Time series of temperature')
axis([0 24 10 25])
grid on
saveas(gcf,'figure110.jpg')



figure(120)
subplot(2,2,1)
plot(Hr,Ta,'o--')
subplot(1,2,2)
plot(Hr,Td,'^-')