% this is the first matlab file
clear all
% import data from CSV or XLS: xlsread
F1 = xlsread ('cwb_2006_0101.csv')
[A,B,C]=xlsread('cwb_2006_0101.csv')
time = F1(:, 3);
RH=F1(:,7);
DWP=F1(:,6);
Tair=F1(:,5);
Hr=F1(:,3);

%�إߤ諰��
DWP(DWP>Tair | DWP ==-9999 )=NaN
RH(RH==-9999)=NaN
RH(RH>=100)=100

%ø�s�Ϫ�
%1
figure(11)
subplot(2,2,1)
plot(time, Tair, 'xb-')
legend('Ta')
xlabel('Local time(Hr)')
ylabel('Temperature(^{o}C)')
title('Temperature Section')
grid on
axis([0 24 15 25])
%----------------------------------
%2
subplot(2,2,2)
plot(time, DWP, '*g-')
legend('DWP')
xlabel('Local time(Hr)')
ylabel('Dew Point(^{o}C)')
title('Dew Point Section')
grid on
axis([0 24 14 17])
%----------------------------------
%3
subplot(2,1,2)
plot(time, RH, 'or-')
legend('Ta')
xlabel('Local time(Hr)')
ylabel('Relative Humidity(%)')
title('Relative Humidity Section')
grid on
axis([0 24 60 110])



