% B05208038 ������
clear all
id = [1:1:28]
rain = [1182,305, 255.1, 97.6, 336.7, 328.1, 48.2, 239, 274.4, 42.5, 185.5, 76.1, 355.6, 313.3, 44.1, 55.1, 102.7, 138.6, 645.8, 467.7, 148.9, 240.5, 172.4, 133.5, 567.5, 114.3, 200.2, 631.4]
%if write
rainrank=cell(1,length(rain))
for i = 1:1:length(rain)
    if  rain(i)>=600
        rainrank(i) = {'A'}
    elseif  rain(i)<600 & rain(i)>=450
        rainrank(i) = {'B'}
    elseif  rain(i)<450 & rain(i)>=300
        rainrank(i) = {'C'}
    elseif  rain(i)<300 & rain(i)>=150
        rainrank(i) = {'D'}
    else 
        rainrank(i) = {'E'}
    end
end
result = {id; rainrank}

%switch write
for i = 1:1:length(rain)
    switch floor(rain(i)/150)
        case {0}
            rrk(i) = {'E'}
        case {1}
            rrk(i) = {'D'}
        case {2}
            rrk(i) = {'C'}
         case {3}
            rrk(i) = {'B'}
        otherwise
            rrk(i)={'A'}
    end
end
