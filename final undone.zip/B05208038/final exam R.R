Encoding("UTF-8")
#B05208038 ������
rm(list =ls(all = TRUE))
setwd("D:/B05208038")
#1
SC<-read.table("2016Sanchong.csv", sep = ",",header = TRUE)
monthlyyearCO <- NULL
monthlyyearPM10 <- NULL
monthlyyearPM25 <- NULL
monthlyyearNOX <- NULL
for(i in c(1:365)){
  avgdata<-seq((i-1)*24+1,(i-1)*24+24)
  i.CO<-SC$CO[avgdata]
  monthlyyearCO[i]<-mean(i.CO)
  i.PM10<-SC$PM10[avgdata]
  monthlyyearPM10[i]<-mean(i.PM10)
  i.PM25<-SC$PM2.5[avgdata]
  monthlyyearPM25[i]<-mean(i.PM25)
  i.NOX<-SC$NOx[avgdata]
  monthlyyearNOX[i]<-mean(i.NOX)
}


#2
#ø��
layout(matrix(c(1,2,3,4),2,2))
plot(1:365, monthlyyearCO, 
     type = 'b', 
     main = 'CO over 2016, Sanchong' , 
     xlab = 'day', 
     ylab = 'density',
     col = 5
)
legend(200,4,"CO density",
       pch = c(15,16),
       col = 5,
       cex = 0.8,
       bty = "n")
plot(1:365, monthlyyearPM25, 
     type = 'b', 
     main = 'PM2.5 over 2016, Sanchong' , 
     xlab = 'day', 
     ylab = 'density',
     col = 6
)
legend(200,60,"PM2.5 density",
       pch = c(15,16),
       col = 6,
       cex = 0.8,
       bty = "n")
plot(1:365, monthlyyearPM10, 
     type = 'b', 
     main = 'PM10 over 2016, Sanchong' , 
     xlab = 'day', 
     ylab = 'density',
     col = 7
)
legend(200,120,"PM10 density",
       pch = c(15,16),
       col = 7,
       cex = 0.8,
       bty = "n")
plot(1:365, monthlyyearNOX, 
     type = 'b', 
     main = 'NOx over 2016, Sanchong' , 
     xlab = 'day', 
     ylab = 'density',
     col = 8
)
legend(200,250,"NOx density",
       pch = c(15,16),
       col = 8,
       cex = 0.8,
       bty = "n")
dev.copy(jpeg," Figure.jpg")
dev.off()

#3
Tfah <- function(Tc){
  Tfah = Tc*1.8+32
  return(Tfah)
}

#4
TTtemp<- NULL
for(i in c(1:366)){
  time<-c((i-1)*24+14)
  i.temp<-SC$AMB_TEMP[time]
  TTtemp[i]<-i.temp
}
DOY <- seq(1:366)
Tf <- Tfah(TTtemp)


#5
#�ݭn������NA
Tf[is.na(Tf)] <- 0
Tf80<- NULL
DOY80 <- NULL
date <- NULL
for(i in DOY){
  if(Tf[i] > 79.99){
    Tf80[i] <- Tf[i] 
    DOY80[i]<- DOY[i]
    date[i] <- SC$date[i]
  }
}

#6
HIndex <- function(Tf, RH){
  HI <- 0.5*(Tf+61+((Tf-68)*1.2)+(RH*0.094))
  return(HI)
}
Tf80
DOY80
#�M��NA��
Tf80<-Tf80[!is.na(Tf80)]
DOY80<-DOY80[!is.na(DOY80)]
date<-date[!is.na(date)]
Tf80
DOY80
HI80 <- HIndex(Tf80, SC$RH[DOY80])
HI80
#7
Class80<- NULL
for(i in length(DOY80)){
  if(Tf80[i]>80 & Tf80[i]<= 86){
    Class80[i]<- 1
  }else if(Tf80[i]>86 & Tf80[i] <= 94){
    Class80[i]<- 2
  }else if(Tf80[i]>94 & Tf80[i] <= 99){
    Class80[i]<- 3
  }else{
    Class80[i]<- 4
  }
}

#8
#as.Date�������|��XD
dataa<- as.Date(DOY80, SC$date)
end <- cbind(dataa, Class80)
write.table(end, file = "Classification.csv",row.names = FALSE, sep = ',')