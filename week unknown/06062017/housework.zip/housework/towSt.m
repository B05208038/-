function[t] = towSt(x, r)
t = 10.^2.* ((x)./100)./r;